import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import './components/navbar';
import navbar from './components/navbar';

function App() {
  return (
    <>
    <h1>Bienvenidos a</h1>
    <h2>Galeria virtual</h2>
    </>
  );
}

export default App;


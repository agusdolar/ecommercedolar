function navbar() {
    return (
        <>
            <nav className="navbar navbar-dark bg-dark">
                <ul>
                    <li>Inicio</li>
                    <li>Productos</li>
                    <li>Contacto</li>
                    <li>Quienes somos</li>
                </ul>
            </nav>
        </>
    );
}

export default navbar;
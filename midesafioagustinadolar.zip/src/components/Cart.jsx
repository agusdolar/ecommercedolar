const Cart = () => {
    return (
        <>
        <h1>I'm Cart</h1>
        </>
    );
}

export default Cart;
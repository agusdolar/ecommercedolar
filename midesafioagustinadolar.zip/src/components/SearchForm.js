import { BsSearch } from 'react-icons/bs';
import { Input, SearchContainer} from './Styledcomponents';


const handleChange = () => {

    const  handleClick = (e) => {
         
         if (e.key === '') {
             
             console.log("Barra espaciadora => ", e.key);
             e.preventDefault();
     }

    return(
        <>
        <SearchContainer>
        <Input onKeyDown={handleChange} />
        </SearchContainer >
        </>
    );
}

export default handleChange;

